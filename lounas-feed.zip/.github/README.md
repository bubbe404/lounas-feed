# Lauttasaari Lunch Feed 🍽️

Automatically generated daily RSS feed for Lauttasaari restaurant lunch menus.

**Feed URL (for Feedly):**
```
https://YOUR_USERNAME.github.io/lounas_feed.xml
```

Includes:
- Casa Mare  
- Makiata (Lauttasaari)  
- Pisara  
- Persilja  
- Bistro Telakka
